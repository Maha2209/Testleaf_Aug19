package week1.date1;

public class Informations {
	public static void main(String[] args) {
		int age = 25;
		long creditNum = 123456778759L;
		float mileage = 20.5f;
		boolean hadLunch = true;
		double bankBalance = 6542.123456;
		char logo = 'H';
		String brandName = null;
		System.out.println("Age of a customer is: " + age);
		System.out.println("Credit Number of a customer is: " + creditNum);
		System.out.println("Mileage: " + mileage);
		System.out.println("boolean statment: " + hadLunch);
		System.out.println("Bank balanace of a customer is: " + bankBalance);
		System.out.println("Car logo: " + logo);
		System.out.println("Car brand name is: " + brandName);
	}
}
