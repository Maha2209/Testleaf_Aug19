package week1.date1;

public class HelloSelenium {
	public static void main(String[] args) {
		System.out.println("Hello Selenium");
	}
}
