package week1.date1;

public class LearnIfCondition {
	public static void main(String[] args) {
		// Problem Statement
		// Find whether the give number is positive or negative
		// Input
		int number = 50;
		// type if-> ctrl +space -> enter

		if (number > 0) {
			System.out.println("postive");

		} else if (number == 0) {
			System.out.println("neutral");

		} else {
			System.out.println("negative");
		}
	}
}
